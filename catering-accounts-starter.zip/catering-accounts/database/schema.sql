CREATE DATABASE IF NOT EXISTS catering_accounts CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE catering_accounts;
-- Spring JPA creates the initial tables from entities on startup in development.
-- For production, use Flyway migrations and set spring.jpa.hibernate.ddl-auto=validate.
