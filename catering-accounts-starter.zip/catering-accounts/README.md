# Catering Accounts — Starter MVP

A mobile-first React + Spring Boot + MySQL starter for a catering business. Currency: INR. This is a development starter, not yet production-ready or fully feature-complete.

## Current implementation
- Customer creation and search by unique mobile number
- Multiple catering functions per customer
- Function records with event date, venue and agreed amount
- Customer payment records and basic overpayment validation
- Business expense records, optionally linked to a function
- Dashboard totals and client function lookup UI
- Validation on core fields

## Not yet implemented
- Secure admin login / authorization
- Supplier bills, supplier payments and ledger UI
- PDF generation and Excel exports
- WhatsApp Business API integration (current official integration requires credentials and approved templates for business-initiated messages)
- Monthly/date-filtered accounting reports, refunds/adjustments and proper accrual accounting
- Cloud deployment configuration, production migrations and automated backups

Do not expose the API publicly until authentication and authorization are added. Use a managed MySQL database, TLS/HTTPS, secrets via environment variables, automated backups and a migration tool before real business use.

## 1. Create database and user
Run in MySQL as an administrator:

```sql
CREATE DATABASE catering_accounts CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'catering_app'@'localhost' IDENTIFIED BY 'replace-with-a-strong-password';
GRANT ALL PRIVILEGES ON catering_accounts.* TO 'catering_app'@'localhost';
FLUSH PRIVILEGES;
```

Set `DB_USERNAME` and `DB_PASSWORD` environment variables, or edit `backend/src/main/resources/application.properties` for local development. Never commit production credentials.

## 2. Run backend
Requires Java 21 and Maven 3.9+.

```bash
cd backend
mvn spring-boot:run
```

API base URL: `http://localhost:8080/api`
Health check: `GET http://localhost:8080/api/health`

## 3. Run frontend
Requires Node.js 22 LTS.

```bash
cd frontend
npm install
npm run dev
```

Open the Vite URL shown in the terminal, typically `http://localhost:5173`.

To use a remote API, create `frontend/.env` with:

```env
VITE_API_URL=https://your-api-domain.example/api
```

Rebuild the frontend after changing this variable.

## API quick examples
Create a customer:

```bash
curl -X POST http://localhost:8080/api/customers \
  -H 'Content-Type: application/json' \
  -d '{"name":"Sample Customer","mobile":"9876543210","address":"Pune"}'
```

Create a function (replace `customerId` with the returned ID):

```bash
curl -X POST http://localhost:8080/api/functions \
  -H 'Content-Type: application/json' \
  -d '{"customerId":1,"eventName":"Wedding Dinner","eventDate":"2026-11-20","venue":"Pune","agreedAmount":125000,"notes":"Dinner catering"}'
```

Record a payment (replace `functionId`):

```bash
curl -X POST http://localhost:8080/api/payments \
  -H 'Content-Type: application/json' \
  -d '{"functionId":1,"paymentDate":"2026-10-16","amount":25000,"method":"UPI","referenceNote":"Advance"}'
```

Record an expense:

```bash
curl -X POST http://localhost:8080/api/expenses \
  -H 'Content-Type: application/json' \
  -d '{"functionId":1,"expenseDate":"2026-10-16","category":"Groceries","description":"Rice and oil","amount":8500,"paidTo":"Local supplier","paymentMethod":"UPI"}'
```

Dashboard: `GET /api/dashboard`
Find customer: `GET /api/customers/search?mobile=9876543210`
Customer functions: `GET /api/customers/{id}/functions`

## Accounting caveat
The current dashboard uses the sum of agreed function amounts as a simple booked-revenue proxy and subtracts entered expenses for an estimated profit. This is not yet a formal profit-and-loss statement: event completion dates, advances, refunds, taxes, discounts, unpaid supplier bills and accrual timing need to be modelled before treating the result as statutory accounts.
