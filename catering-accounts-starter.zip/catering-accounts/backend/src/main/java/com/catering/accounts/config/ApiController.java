package com.catering.accounts.config;

import com.catering.accounts.customer.*;
import com.catering.accounts.function.*;
import com.catering.accounts.payment.*;
import com.catering.accounts.expense.*;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.math.BigDecimal;
import java.util.*;

@RestController @RequestMapping("/api") @CrossOrigin(origins={"http://localhost:5173"})
public class ApiController {
 private final CustomerRepository customers; private final FunctionRepository functions; private final CustomerPaymentRepository payments; private final ExpenseRepository expenses;
 public ApiController(CustomerRepository c, FunctionRepository f, CustomerPaymentRepository p, ExpenseRepository e){customers=c;functions=f;payments=p;expenses=e;}
 @GetMapping("/health") public Map<String,String> health(){return Map.of("status","ok","currency","INR");}
 @GetMapping("/customers") public List<Customer> customers(){return customers.findAll();}
 @GetMapping("/customers/search") public Customer searchCustomer(@RequestParam String mobile){return customers.findByMobile(mobile).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Customer not found"));}
 @PostMapping("/customers") @ResponseStatus(HttpStatus.CREATED) public Customer createCustomer(@Valid @RequestBody Customer customer){if(customers.findByMobile(customer.getMobile()).isPresent()) throw new ResponseStatusException(HttpStatus.CONFLICT,"Mobile number already exists"); return customers.save(customer);}
 @GetMapping("/customers/{id}/functions") public List<CateringFunction> customerFunctions(@PathVariable Long id){if(!customers.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Customer not found");return functions.findByCustomerIdOrderByEventDateDesc(id);}
 @PostMapping("/functions") @ResponseStatus(HttpStatus.CREATED) public CateringFunction createFunction(@Valid @RequestBody FunctionRequest r){CateringFunction f=new CateringFunction();f.setCustomer(customers.findById(r.customerId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Customer not found")));f.setEventName(r.eventName());f.setEventDate(r.eventDate());f.setVenue(r.venue());f.setAgreedAmount(r.agreedAmount());f.setNotes(r.notes());return functions.save(f);}
 @GetMapping("/functions") public List<CateringFunction> functions(){return functions.findAll();}
 @PostMapping("/payments") @ResponseStatus(HttpStatus.CREATED) public CustomerPayment createPayment(@Valid @RequestBody PaymentRequest r){CateringFunction f=functions.findById(r.functionId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Function not found"));BigDecimal paid=payments.totalForFunction(f.getId());if(paid.add(r.amount()).compareTo(f.getAgreedAmount())>0) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Payment exceeds remaining balance");CustomerPayment p=new CustomerPayment();p.setCateringFunction(f);p.setPaymentDate(r.paymentDate());p.setAmount(r.amount());p.setMethod(r.method());p.setReferenceNote(r.referenceNote());return payments.save(p);}
 @GetMapping("/functions/{id}/payments") public List<CustomerPayment> functionPayments(@PathVariable Long id){return payments.findByCateringFunctionIdOrderByPaymentDateDesc(id);}
 @PostMapping("/expenses") @ResponseStatus(HttpStatus.CREATED) public BusinessExpense createExpense(@Valid @RequestBody ExpenseRequest r){BusinessExpense e=new BusinessExpense();if(r.functionId()!=null)e.setCateringFunction(functions.findById(r.functionId()).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND,"Function not found")));e.setExpenseDate(r.expenseDate());e.setCategory(r.category());e.setDescription(r.description());e.setAmount(r.amount());e.setPaidTo(r.paidTo());e.setPaymentMethod(r.paymentMethod());return expenses.save(e);}
 @GetMapping("/expenses") public List<BusinessExpense> expenses(){return expenses.findAll();}
 @GetMapping("/dashboard") public Map<String,Object> dashboard(){BigDecimal revenue=functions.findAll().stream().map(CateringFunction::getAgreedAmount).reduce(BigDecimal.ZERO,BigDecimal::add);BigDecimal received=payments.findAll().stream().map(CustomerPayment::getAmount).reduce(BigDecimal.ZERO,BigDecimal::add);BigDecimal cost=expenses.totalExpenses();return Map.of("totalRevenue",revenue,"paymentsReceived",received,"pendingClientPayments",revenue.subtract(received).max(BigDecimal.ZERO),"totalExpenses",cost,"estimatedProfit",revenue.subtract(cost),"functionCount",functions.count(),"customerCount",customers.count());}
 public record FunctionRequest(@jakarta.validation.constraints.NotNull Long customerId,@jakarta.validation.constraints.NotBlank String eventName,@jakarta.validation.constraints.NotNull java.time.LocalDate eventDate,String venue,@jakarta.validation.constraints.NotNull @jakarta.validation.constraints.DecimalMin("0.00") BigDecimal agreedAmount,String notes){}
 public record PaymentRequest(@jakarta.validation.constraints.NotNull Long functionId,@jakarta.validation.constraints.NotNull java.time.LocalDate paymentDate,@jakarta.validation.constraints.NotNull @jakarta.validation.constraints.DecimalMin("0.01") BigDecimal amount,@jakarta.validation.constraints.NotBlank String method,String referenceNote){}
 public record ExpenseRequest(Long functionId,@jakarta.validation.constraints.NotNull java.time.LocalDate expenseDate,@jakarta.validation.constraints.NotBlank String category,@jakarta.validation.constraints.NotBlank String description,@jakarta.validation.constraints.NotNull @jakarta.validation.constraints.DecimalMin("0.01") BigDecimal amount,String paidTo,@jakarta.validation.constraints.NotBlank String paymentMethod){}
}
