package com.catering.accounts.function;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface FunctionRepository extends JpaRepository<CateringFunction,Long> {
  List<CateringFunction> findByCustomerIdOrderByEventDateDesc(Long customerId);
}
