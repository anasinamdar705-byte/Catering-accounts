package com.catering.accounts.expense;

import com.catering.accounts.function.CateringFunction;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity @Table(name="business_expenses")
public class BusinessExpense {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne private CateringFunction cateringFunction; // null means general business expense
  @NotNull private LocalDate expenseDate;
  @NotBlank @Size(max=100) private String category;
  @NotBlank @Size(max=200) private String description;
  @NotNull @DecimalMin("0.01") @Digits(integer=12,fraction=2) @Column(precision=14,scale=2,nullable=false) private BigDecimal amount;
  @Size(max=120) private String paidTo;
  @NotBlank @Pattern(regexp="CASH|UPI|BANK_TRANSFER|CARD|CHEQUE") private String paymentMethod;
  public Long getId(){return id;} public CateringFunction getCateringFunction(){return cateringFunction;} public void setCateringFunction(CateringFunction v){cateringFunction=v;}
  public LocalDate getExpenseDate(){return expenseDate;} public void setExpenseDate(LocalDate v){expenseDate=v;}
  public String getCategory(){return category;} public void setCategory(String v){category=v;}
  public String getDescription(){return description;} public void setDescription(String v){description=v;}
  public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;}
  public String getPaidTo(){return paidTo;} public void setPaidTo(String v){paidTo=v;}
  public String getPaymentMethod(){return paymentMethod;} public void setPaymentMethod(String v){paymentMethod=v;}
}
