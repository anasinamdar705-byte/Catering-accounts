package com.catering.accounts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CateringAccountsApplication {
  public static void main(String[] args) { SpringApplication.run(CateringAccountsApplication.class, args); }
}
