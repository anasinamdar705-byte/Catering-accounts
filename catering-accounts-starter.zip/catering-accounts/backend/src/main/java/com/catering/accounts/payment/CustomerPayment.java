package com.catering.accounts.payment;

import com.catering.accounts.function.CateringFunction;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity @Table(name="customer_payments")
public class CustomerPayment {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne(optional=false) private CateringFunction cateringFunction;
  @NotNull private LocalDate paymentDate;
  @NotNull @DecimalMin(value="0.01") @Digits(integer=12,fraction=2) @Column(precision=14,scale=2,nullable=false) private BigDecimal amount;
  @NotBlank @Pattern(regexp="CASH|UPI|BANK_TRANSFER|CARD|CHEQUE", message="Unsupported payment method") private String method;
  @Size(max=300) private String referenceNote;
  public Long getId(){return id;} public CateringFunction getCateringFunction(){return cateringFunction;} public void setCateringFunction(CateringFunction v){cateringFunction=v;}
  public LocalDate getPaymentDate(){return paymentDate;} public void setPaymentDate(LocalDate v){paymentDate=v;}
  public BigDecimal getAmount(){return amount;} public void setAmount(BigDecimal v){amount=v;}
  public String getMethod(){return method;} public void setMethod(String v){method=v;}
  public String getReferenceNote(){return referenceNote;} public void setReferenceNote(String v){referenceNote=v;}
}
