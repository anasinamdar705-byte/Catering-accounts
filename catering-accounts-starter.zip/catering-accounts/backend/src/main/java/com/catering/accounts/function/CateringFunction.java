package com.catering.accounts.function;

import com.catering.accounts.customer.Customer;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity @Table(name="catering_functions")
public class CateringFunction {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @ManyToOne(optional=false, fetch=FetchType.EAGER) private Customer customer;
  @NotBlank @Size(max=140) private String eventName;
  @NotNull private LocalDate eventDate;
  @Size(max=255) private String venue;
  @NotNull @DecimalMin("0.00") @Digits(integer=12,fraction=2) @Column(precision=14,scale=2,nullable=false) private BigDecimal agreedAmount;
  @Size(max=500) private String notes;
  public Long getId(){return id;} public Customer getCustomer(){return customer;} public void setCustomer(Customer v){customer=v;}
  public String getEventName(){return eventName;} public void setEventName(String v){eventName=v;}
  public LocalDate getEventDate(){return eventDate;} public void setEventDate(LocalDate v){eventDate=v;}
  public String getVenue(){return venue;} public void setVenue(String v){venue=v;}
  public BigDecimal getAgreedAmount(){return agreedAmount;} public void setAgreedAmount(BigDecimal v){agreedAmount=v;}
  public String getNotes(){return notes;} public void setNotes(String v){notes=v;}
}
