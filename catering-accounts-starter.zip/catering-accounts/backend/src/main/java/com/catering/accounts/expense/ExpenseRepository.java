package com.catering.accounts.expense;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.math.BigDecimal;
public interface ExpenseRepository extends JpaRepository<BusinessExpense,Long> {
 @Query("select coalesce(sum(e.amount),0) from BusinessExpense e") BigDecimal totalExpenses();
 @Query("select coalesce(sum(e.amount),0) from BusinessExpense e where e.cateringFunction.id = :functionId") BigDecimal totalForFunction(Long functionId);
}
