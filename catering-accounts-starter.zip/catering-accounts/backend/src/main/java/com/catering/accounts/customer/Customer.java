package com.catering.accounts.customer;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.time.LocalDateTime;

@Entity @Table(name="customers", uniqueConstraints=@UniqueConstraint(columnNames="mobile"))
public class Customer {
  @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
  @NotBlank @Size(max=120) private String name;
  @Column(nullable=false, unique=true, length=15) @NotBlank @Pattern(regexp="[0-9]{10,15}", message="Mobile must contain 10 to 15 digits") private String mobile;
  @Size(max=255) private String address;
  private LocalDateTime createdAt = LocalDateTime.now();
  public Long getId(){return id;} public String getName(){return name;} public void setName(String v){name=v;}
  public String getMobile(){return mobile;} public void setMobile(String v){mobile=v;}
  public String getAddress(){return address;} public void setAddress(String v){address=v;}
  public LocalDateTime getCreatedAt(){return createdAt;}
}
