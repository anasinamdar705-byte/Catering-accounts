package com.catering.accounts.payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.math.BigDecimal;
import java.util.List;
public interface CustomerPaymentRepository extends JpaRepository<CustomerPayment,Long> {
  List<CustomerPayment> findByCateringFunctionIdOrderByPaymentDateDesc(Long functionId);
  @Query("select coalesce(sum(p.amount),0) from CustomerPayment p where p.cateringFunction.id = :functionId") BigDecimal totalForFunction(@Param("functionId") Long functionId);
}
